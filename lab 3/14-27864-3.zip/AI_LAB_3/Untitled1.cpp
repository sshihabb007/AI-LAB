#include<bits/stdc++.h>

using namespace std;

int main()
{
	char square;
	int squareA=0,squareB=0,i;

	while(1)
	{
		cout<<"Enter square A or B: ";
		cin>>square;
		if(square=='A')
		{
			cout<<"enter status(dirty=1 or clean=0): ";
			cin>>squareA;
			if(squareA==0)
			{
				printf("\nRight\n");
			}
			else if(squareA==1)
			{
				squareA=0;
				printf("\nSuck\n");
			}
		}
		else if(square=='B')
		{
			cout<<"enter status(dirty=1 or clean=0): ";
			cin>>squareB;
			if(squareB==0)
			{
				printf("\nLeft\n");
			}
			else if(squareB==1)
			{
				squareB=0;
				printf("\nSuck\n");
			}
		}
	}

	return 0;
}
